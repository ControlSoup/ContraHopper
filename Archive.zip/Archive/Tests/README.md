# Tests

This folder contains diffrent informal test reports that where made in the process of designing and operating ContraHopper. 

## Impact Test

###### Overview
While attempting to design the laning legs, I found out that in order to determine impact loads, you need to make an assumption about impact duration or the deceleration distance on impact. The assumption made here dramatically changes the expected loads. Because of this I attempted to do a series of drop tests to measure impact G's. 

###### Conclusion
Using a MEM's accelerometer is a poor choice for imapct testing, the results staturated at 4gs. I chose to design to double this saturated result (8gs) with knowledge that harware testing would be needed in the future. 
